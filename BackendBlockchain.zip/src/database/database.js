const mysql = require('mysql2');

const connect = mysql.createConnection({
host: 'localhost',
user: 'root',
password: 'sseeaways',
database: "blockchain"
});
// const connect = mysql.createConnection({
//   host: 'localhost',
//   user: 'admin_ublockchainfarm',
//   password: 'Kigu65_8',
//   database: "admin_blockchainfarm",
// });
module.exports.connect = connect