const customerService = require('./customerService');
const walletService = require('./walletService');
const { jsonResp } = require('../models/jsonResponse');
const customer2FA = require('./customer2FA');
const customerTron = require('./customerTron');
module.exports = {
    //Customer log-in service.
    addTitleDetailUser: (params) =>{
        return customerService.addTitleDetailUser(params)
    }, 
    deleteTitleDetailUser : (params) =>{
        return customerService.deleteTitleDetailUser(params)
    }, 
    editTitleDetailUser : (params) =>{
        return customerService.editTitleDetailUser(params)
    }, 
    getTitleDetailUser: (params) =>{
        return customerService.getTitleDetailUser(params)
    },
    getProcedureUser: (params) =>{
        return customerService.getProcedureUser(params)
    },
    editProcedureUser: (params) =>{
        return customerService.editProcedureUser(params)
    },
    deleteProcedureUser: (params) =>{
        return customerService.deleteProcedureUser(params)
    },
    addProcedureUser : (params) =>{
        return customerService.addProcedureUser(params)
    },
    testTron: (params) =>{
        return customerTron.testTron(params)
    },
    deleteNotification : (params) =>{
        return customerService.deleteNotification(params)
    },
    getNewsDetail: (params) => {
        return customerService.getNewsDetail(params)
    },
    getNewsBlock: (params) => {
        return customerService.getNewsBlock(params)
    },
    detailQR: (params) => {
        return customerService.detailQR(params)
    },
    addTokenApp: (params) => {
        return customerService.addTokenApp(params)
    },
    getProfileUser: (params) => {
        return customerService.getProfileUser(params)
    },
    turnOff2FA: (params) => {
        return customer2FA.turnOff2FA(params)
    },
    turnOn2FA: (params) => {
        return customer2FA.turnOn2FA(params)
    },
    verifyOTPToken: (params) => {
        return customer2FA.verifyOTPToken(params)
    },
    generateOTPToken: (params) => {
        return customer2FA.generateOTPToken(params)
    },
    getQR: (params) => {
        return customer2FA.generateUniqueSecret(params)
    },
    getProfileFarm: (params) => {
        return customerService.getProfileFarm(params)
    },
    loginCode: (params) => {
        return customerService.loginCode(params)
    },
    addCodeLogin: (params) => {
        return customerService.addCodeLogin(params)
    },
    editProfileFarm: (params) => {
        return customerService.editProfileFarm(params)
    },
    updateProfileFarm: (params) => {
        return customerService.updateProfileFarm(params)
    },
    signUpString: (params) => {
        return customerService.signUpString(params)
    },
    addPlanting: (params) => {
        return customerService.addPlanting(params)
    },
    getStamp: (params) => {
        return customerService.getStamp(params)
    },
    addStamp: (params) => {
        return customerService.addStamp(params)
    },
    addPack: (params) => {
        return customerService.addPack(params)
    },
    getListUser: (params) => {
        return customerService.getListUser(params)
    },
    deleteFarm: (params) => {
        return customerService.deleteFarm(params)
    },
    updateFarm: (params) => {
        return customerService.updateFarm(params)
    },
    getFarm: (params) => {
        return customerService.getFarm(params)
    },
    addFarm: (params) => {
        return customerService.addFarm(params)
    },
    updateFertilizers: (params) => {
        return customerService.updateFertilizers(params)
    },
    deleteFertilizers: (params) => {
        return customerService.deleteFertilizers(params)
    },
    addFertilizers: (params) => {
        return customerService.addFertilizers(params)
    },
    deleteNews: (params) => {
        return customerService.deleteNews(params)
    },
    addNews: (params) => {
        return customerService.addNews(params)
    },
    changePassword: (params) => {
        return customerService.changePassword(params)
    },
    notificationFireBase: (params,socketIo,io) => {
        return customerService.notificationFireBase(params,socketIo,io)
    },
    getNews: function (params) {
        return customerService.getNews(params)
    },
    addManipulation: function (params) {
        return customerService.addManipulation(params)
    },
    fertilizers: function (params) {
        return customerService.fertilizers(params)
    },
    detailTitle: function (params) {
        return customerService.detailTitle(params)
    },
    historyNotification: function (params) {
        return customerService.historyNotification(params)
    },
    listProduct: function (params) {
        return customerService.listProduct(params);
    },
    signUpService: function (params) {
        return customerService.signUp(params);
    },
    updateRole: function (params) {
        return customerService.updateRole(params)
    },
    city: function (params) {
        return customerService.city(params)
    },
    //Customer log-in service.
    logInService: function (params, socketIO) {
        return customerService.logIn(params, socketIO);
    },
    district: function (params) {
        return customerService.district(params)
    },
    procedure: function (params) {
        return customerService.procedure(params)
    },
    logOut: function (params, socketIO) {
        return customerService.logOut(params, socketIO)
    },
    ward: function (params) {
        return customerService.ward(params)
    },
    checkQR: function (params) {
        return customerService.checkQR(params)
    },

    //Check email sign-up.
    checkEmailService: function (params) {
        return customerService.checkEmail(params);
    },

    //Get coin list.
    getCoinListService: function (params) {
        return walletService.getCoinListService(params);
    },

    //Test coinpayments.
    testCoinPayment: function (params) {
        return customerService.testCoinPayment(params);
    },
}