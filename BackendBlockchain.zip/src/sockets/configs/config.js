const path = require('./pathConfig.json');
const service = require('./serviceConfig.json')
const validate = require('./validationConfig.json')

module.exports = { path, service, validate }