const connect = require('../../database/database')
module.exports = {
    getTitleDetailUser: async function (IdProcedure) {
        var query = `SELECT * FROM tb_titledetailuser WHERE IdProcedure=${IdProcedure}`
        return new Promise((resolve, reject) => {
            connect.connect.query(query, (err, rows) => {
                if (err) return reject(err);
                resolve(rows);
            });
        });
    },
    editTitleDetailUser: async function (Name, Detail, Images,IdTitle,IdProcedure) {
        const sql = `UPDATE tb_titledetailuser SET Name='${Name}' , Detail='${Detail}' ,Images='${Images}' WHERE IdTitle=${IdTitle} AND IdProcedure=${IdProcedure};`
        return new Promise((resolve, reject) => {
            connect.connect.query(sql, (err, rows) => {
                if (err) return reject({
                    message: "Lỗi hệ thống !",
                    status: false,
                    err
                });
                resolve({
                    message: "Thay đổi nội dung qui trình thành công ! ",
                    status: true
                });
            });

        });
    },
    deleteTitleDetailUser: async function (idTitle) {
        var query = `DELETE FROM tb_titledetailuser WHERE IdTitle=${idTitle} `
        return new Promise((resolve, reject) => {
            connect.connect.query(query, (err, rows) => {
                if (err) return reject(err);
                resolve({
                    message: "Xóa nội dùng qui trình thành công",
                    status: true
                });
            });
        });
    },
    addtitledetailuser: async function (IdProcedure, Name, Detail, Images) {
        const sqlNotification = `INSERT INTO tb_titledetailuser set ?`
        const cusObj = {
            Name,
            IdProcedure,
            Detail,
            Images
        }
        return new Promise((resolve, reject) => {
            connect.connect.query(sqlNotification, cusObj, (err, rows) => {
                if (err)
                    return reject({
                        status: false,
                        message: "Thêm nội dung qui trình thất bại !",
                        err
                    });
                resolve({
                    status: true,
                    message: "Thêm nội dung qui trình thành công !",

                });
            });
        })
    },
    getProcedureUser: async function (phone) {
        var query = `SELECT * FROM tb_procedureuser WHERE phone='${phone}'`
        return new Promise((resolve, reject) => {
            connect.connect.query(query, (err, rows) => {
                if (err) return reject(err);
                resolve(rows);
            });
        });
    },
    editProcedureUser: async function (phone, Name, priceMin, priceMax, id) {
        const sql = `UPDATE tb_procedureuser SET Name='${Name}' , priceMin=${priceMin} ,priceMax=${priceMax} WHERE phone='${phone}' AND IdProcedure=${id} ;`
        console.log(sql);
        return new Promise((resolve, reject) => {
            connect.connect.query(sql, (err, rows) => {
                if (err) return reject({
                    message: "Lỗi hệ thống !",
                    status: false,
                    err
                });
                resolve({
                    message: "Thay đổi qui trình thành công ! ",
                    status: true
                });
            });

        });
    },
    deleteProcedureUser: async function (id, phone) {
        var query = `DELETE FROM tb_procedureuser WHERE IdProcedure=${id} and phone='${phone}'`
        return new Promise((resolve, reject) => {
            connect.connect.query(query, (err, rows) => {
                if (err) return reject(err);
                resolve({
                    message: "Xóa qui trình thành công",
                    status: true
                });
            });
        });
    },
    addProcedureUser: async function (Phone, Name, priceMin, priceMax) {
        const sqlNotification = `INSERT INTO tb_procedureuser set ?`
        const cusObj = {
            Phone,
            Name,
            priceMin,
            priceMax
        }
        return new Promise((resolve, reject) => {
            connect.connect.query(sqlNotification, cusObj, (err, rows) => {
                if (err)
                    return reject({
                        status: false,
                        message: "Thêm qui trình thất bại !",
                        err
                    });
                resolve({
                    status: true,
                    message: "Thêm quy trình thành công !",

                });
            });
        })
    },
    deleteNotification: async function (phone, id) {
        var query = `DELETE FROM tb_detailnotification WHERE idDetailNotification=${id} and phone='${phone}'`
        return new Promise((resolve, reject) => {
            connect.connect.query(query, (err, rows) => {
                if (err) return reject(err);
                resolve({
                    message: "Xóa thông báo thành công",
                    status: true
                });
            });
        });
    },
    getNewsDetail: async function (id) {
        var query = `SELECT * FROM tb_tintuc WHERE id=${id}`
        return new Promise((resolve, reject) => {
            connect.connect.query(query, (err, rows) => {
                if (err) return reject(err);
                resolve(rows);
            });
        });
    },
    getNewsBlock: async function (token) {
        var query = `SELECT * FROM tb_tintuc `
        return new Promise((resolve, reject) => {
            connect.connect.query(query, (err, rows) => {
                if (err) return reject(err);
                resolve(rows);
            });
        });
    },
    getToken: async function (token) {
        var query = `SELECT token FROM tb_token WHERE token='${token}' `
        return new Promise((resolve, reject) => {
            connect.connect.query(query, (err, rows) => {
                if (err) return reject(err);
                resolve(rows);
            });
        });
    },
    addToken: async function (token) {
        const sqlNotification = `INSERT INTO tb_token set ?`
        const cusObj = {

            token,
        }
        return new Promise((resolve, reject) => {
            connect.connect.query(sqlNotification, cusObj, (err, rows) => {
                if (err)
                    return reject({
                        status: false,
                        message: "Thêm mã token thất bại !",
                        err
                    });
                resolve({
                    status: true,
                    message: "Thêm mã token thành công !",

                });
            });
        })
    },
    getTokenUser: async function (token) {
        var query = `SELECT * FROM tb_token WHERE token='${token}'`
        return new Promise((resolve, reject) => {
            connect.connect.query(query, (err, rows) => {
                if (err) return reject(err);
                resolve(rows);
            });
        });
    },
    getAllToken: async function (token) {
        var query = `SELECT * FROM tb_token `
        return new Promise((resolve, reject) => {
            connect.connect.query(query, (err, rows) => {
                if (err) return reject(err);
                resolve(rows);
            });
        });
    },
    checkLoginCode: async function (codelogin) {
        var query = `SELECT * FROM tb_user WHERE codelogin='${codelogin}'`
        return new Promise((resolve, reject) => {
            connect.connect.query(query, (err, rows) => {
                if (err) return reject(err);
                resolve(rows);
            });
        });
    },
    getWallet: async function (phone) {
        const sql = `SELECT * FROM tb_wallets where phone= '${phone}'`
        return new Promise((resolve, reject) => {
            connect.connect.query(sql, (err, rows) => {
                if (err) return reject({
                    message: "Lỗi hệ thống !",
                    status: false,
                    err
                });
                resolve(rows);
            });

        });
    },
    edit2fa: async function (phone, flag) {
        var sql = ""
        if (flag) {
            sql = `UPDATE tb_user SET twofa=1  WHERE phone='${phone}' ;`

        } else {
            sql = `UPDATE tb_user SET twofa=0  WHERE phone='${phone}' ;`

        }
        return new Promise((resolve, reject) => {
            connect.connect.query(sql, (err, rows) => {
                if (err) return reject({
                    message: "Lỗi hệ thống !",
                    status: false,
                    err
                });
                if (flag) {
                    resolve({
                        message: "Bật 2Fa thành công ! ",
                        status: true
                    });
                } else {
                    resolve({
                        message: "Tắt 2Fa thành công ! ",
                        status: true
                    });
                }
            });

        });
    },
    editSecret: async function (phone, secret) {
        const sql = `UPDATE tb_user SET secret='${secret}' WHERE phone='${phone}' ;`
        console.log(sql);
        return new Promise((resolve, reject) => {
            connect.connect.query(sql, (err, rows) => {
                if (err) return reject({
                    message: "Lỗi hệ thống !",
                    status: false,
                    err
                });
                resolve({
                    message: "Thay đổi secret thành công ! ",
                    status: true
                });
            });

        });
    },
    getProfilePhone: async function (phone) {
        const sql = `SELECT * FROM tb_user where phone= ${phone}`
        return new Promise((resolve, reject) => {
            connect.connect.query(sql, (err, rows) => {
                if (err) return reject({
                    message: "Lỗi hệ thống !",
                    status: false,
                    err
                });
                resolve(rows);
            });

        });
    },
    addSignUpCodeLogin: async function (phone, data) {
        const sql = `UPDATE tb_user SET codelogin='${data}', active=0 WHERE phone='${phone}' ;`
        console.log(sql);
        return new Promise((resolve, reject) => {
            connect.connect.query(sql, (err, rows) => {
                if (err) return reject({
                    message: "Lỗi hệ thống !",
                    status: false,
                    err
                });
                resolve({
                    message: "Tạo mã login thành công !",
                    status: true
                });
            });

        });
    },
    editCodeLogin: async function (codelogin) {
        const sql = `UPDATE tb_codelogin
        SET active=1 WHERE code='${codelogin}' ;`
        console.log(sql);
        return new Promise((resolve, reject) => {
            connect.connect.query(sql, (err, rows) => {
                if (err) return reject({
                    message: "Lỗi hệ thống !",
                    status: false,
                    err
                });
                resolve({
                    message: "Tạo mã login thành công !",
                    status: true
                });
            });

        });
    },
    checkCodeLogin: async function (codelogin) {
        var query = `SELECT * FROM tb_codelogin WHERE code='${codelogin}' and active=1`
        return new Promise((resolve, reject) => {
            connect.connect.query(query, (err, rows) => {
                if (err) return reject(err);
                resolve(rows);
            });
        });
    },
    addCodeLogin: async function (code) {
        const sqlNotification = `INSERT INTO tb_codelogin set ?`
        const cusObj = {
            active: 0,
            code
        }
        return new Promise((resolve, reject) => {
            connect.connect.query(sqlNotification, cusObj, (err, rows) => {
                if (err)
                    return reject({
                        status: false,
                        message: "Thêm mã code thất bại !",
                        err
                    });
                resolve({
                    status: true,
                    message: "Thêm mã code thành công !",

                });
            });
        })
    },
    editProfileFarm: async function (phone, latitude, longitude, width, height, quantity) {
        const sql = `UPDATE tb_profilefarm
        SET quantity='${quantity}', width='${width}', latitude='${latitude}', longitude=${longitude} , height ='${height}' WHERE phone='${phone}' ;`
        console.log(sql);
        return new Promise((resolve, reject) => {
            connect.connect.query(sql, (err, rows) => {
                if (err) return reject({
                    message: "Lỗi hệ thống !",
                    status: false,
                    err

                });
                resolve({
                    message: "Cập nhật thông  tin nông trại thành công !",
                    status: true
                });
            });

        });
    },
    addProfilefarm: async function (phone, latitude, longitude, width, height, quantity) {
        const sqlNotification = `INSERT INTO tb_profilefarm set ?`
        const cusObj = {
            phone,
            latitude,
            longitude,
            width,
            height,
            quantity
        }
        return new Promise((resolve, reject) => {
            connect.connect.query(sqlNotification, cusObj, (err, rows) => {
                if (err)
                    return reject({
                        status: false,
                        message: "Cập nhật thông tin nông trại thất bại!",
                        err
                    });
                resolve({
                    status: true,
                    message: "Cập nhật thông tin nông trại thành công",

                });
            });
        })
    },
    checkCodeFruit: async function (code) {
        var query = `SELECT * FROM tb_fruit WHERE code='${code}'`
        return new Promise((resolve, reject) => {
            connect.connect.query(query, (err, rows) => {
                if (err) return reject(err);
                resolve(rows);
            });
        });
    },
    checkCodeGarden: async function (code) {
        var query = `SELECT * FROM tb_garden WHERE code='${code}'`
        return new Promise((resolve, reject) => {
            connect.connect.query(query, (err, rows) => {
                if (err) return reject(err);
                resolve(rows);
            });
        });
    },
    checkProfileFarm: async function (phone) {
        var query = `SELECT * FROM tb_profilefarm WHERE phone='${phone}'`
        return new Promise((resolve, reject) => {
            connect.connect.query(query, (err, rows) => {
                if (err) return reject(err);
                resolve(rows);
            });
        });
    },
    addPlantingseason: async function (phone, latitude, longitude, describe) {
        const sqlNotification = `INSERT INTO tb_plantingseason set ?`
        const cusObj = {
            phone,
            latitude,
            longitude,
            describe
        }
        return new Promise((resolve, reject) => {
            connect.connect.query(sqlNotification, cusObj, (err, rows) => {
                if (err)
                    return reject({
                        status: false,
                        message: "Thâm nhật ký sản xuất thất bại !",
                        err
                    });
                resolve({
                    status: true,
                    message: "Thêm nhật ký sản xuất thành công!",

                });
            });
        })
    },
    deleteFarm: async function (id) {
        console.log("oiko");

        var sql = `DELETE FROM tb_farm WHERE id=${id}`
        return new Promise((resolve, reject) => {
            connect.connect.query(sql, (err, rows) => {
                if (err) return reject({
                    status: false,
                    message: "Lỗi hệ thống ",
                    err
                });
                resolve({
                    message: "Xóa nông trại thành công thành công !",
                    status: true
                });
            });

        });
    },
    updateFarm: async function (id, name, width, height) {
        const sql = `UPDATE tb_farm
        SET name='${name}', width='${width}' , height ='${height}' WHERE id='${id}' ;`
        console.log(sql);
        return new Promise((resolve, reject) => {
            connect.connect.query(sql, (err, rows) => {
                if (err) return reject({
                    message: "Lỗi hệ thống !",
                    status: false,
                    err

                });
                resolve({
                    message: "Cập nhật nông trại thành công !",
                    status: true
                });
            });

        });
    },
    addStamp: async function (phone, harvest, seristart, seriend, codeqr) {
        const sqlNotification = `INSERT INTO tb_stamp set ?`
        const cusObj = {
            phone,
            harvest,
            seristart,
            seriend,
            codeqr
        }
        return new Promise((resolve, reject) => {
            connect.connect.query(sqlNotification, cusObj, (err, rows) => {
                if (err)
                    return reject({
                        status: false,
                        message: "Kích hoạt tem thất bại !",
                        err
                    });
                resolve({
                    status: true,
                    message: "Kích hoạt tem thành công !",
                    data: codeqr
                });
            });
        })
    },
    getStamp: async (codeqr) => {
        var query = `SELECT * FROM tb_stamp WHERE codeqr = '${codeqr}'`
        return new Promise((resolve, reject) => {

            connect.connect.query(query, (err, rows) => {
                if (err) return reject(err);
                resolve({
                    data: rows[0],
                    status: true,
                    message: "Quét mã QR thành công ! "
                });
            });
        });
    },
    addPack: async function (phone, latitude, longitude, describe) {
        const sqlNotification = `INSERT INTO tb_pack set ?`
        const cusObj = {
            phone,
            latitude,
            longitude,
            describe
        }
        return new Promise((resolve, reject) => {
            connect.connect.query(sqlNotification, cusObj, (err, rows) => {
                if (err)
                    return reject({
                        status: false,
                        message: "Đóng gói thất bại !",
                        err
                    });
                resolve({
                    status: true,
                    message: "Đóng gói thành công !"
                });
            });
        })
    },
    addFarm: async function (phone, name, width, height) {
        const sqlNotification = `INSERT INTO tb_farm set ?`
        const cusObj = {
            phone,
            name,
            width,
            height
        }
        return new Promise((resolve, reject) => {
            connect.connect.query(sqlNotification, cusObj, (err, rows) => {
                if (err)
                    return reject({
                        status: false,
                        message: "Thêm nông trại thất bại !"
                    });
                resolve({
                    status: true,
                    message: "Thêm nông trại thành công !"
                });
            });
        })
    },
    addNotification: async function (phone, detail, title) {
        const sqlNotification = `INSERT INTO tb_detailnotification set ?`
        const cusObj = {
            title,
            detail,
            phone
        }
        return new Promise((resolve, reject) => {
            connect.connect.query(sqlNotification, cusObj, (err, rows) => {
                if (err)
                    return reject(err);
                resolve(rows);
            });
        })
    },
    getFarm: async function (phone) {
        const query = `SELECT * FROM tb_farm WHERE phone='${phone}'
       `;
        return new Promise((resolve, reject) => {

            connect.connect.query(query, (err, rows) => {
                if (err) return reject(err);
                resolve(rows);
            });

        });
    },
    getNews: async function (phone) {
        const query = `SELECT * FROM tb_news
       `;
        return new Promise((resolve, reject) => {

            connect.connect.query(query, (err, rows) => {
                if (err) return reject(err);
                resolve(rows);
            });

        });
    },
    update: async function (phone) {

    },

    checkUser: async function (phone) {
        const query = `SELECT * FROM tb_user
        WHERE phone ='${phone}' 
       `;
        return new Promise((resolve, reject) => {

            connect.connect.query(query, (err, rows) => {
                if (err) return reject(err);
                resolve(rows);
            });

        });
    },
    checkAllNotifiation: async function (phone) {
        const query = `SELECT * FROM tb_notification  
       `;
        return new Promise((resolve, reject) => {

            connect.connect.query(query, (err, rows) => {
                if (err) return reject(err);
                resolve(rows);
            });

        });
    },
    checkAllNews: async function (phone) {
        const query = `SELECT * FROM tb_news  
       `;
        return new Promise((resolve, reject) => {

            connect.connect.query(query, (err, rows) => {
                if (err) return reject(err);
                resolve(rows);
            });

        });
    },
    // checkAllDetailNotification: async function () {
    //     const query = `SELECT * FROM tb_detailnotification`
    //     return new Promise((resolve, reject) => {

    //         connect.connect.query(query, (err, rows) => {
    //             if (err) return reject(err);
    //             resolve(rows);
    //         });
    //     });
    // },
    checkProduce: async function (produce) {
        const query = `SELECT * FROM tb_procedure WHERE idProcedure=${produce}`;
        return new Promise((resolve, reject) => {
            connect.connect.query(query, (err, rows) => {
                if (err) return reject(err);
                resolve(rows);
            });
        });
    },
    checkAllDetailNotification: async function () {
        const query = `SELECT * FROM tb_detailnotification`
        return new Promise((resolve, reject) => {

            connect.connect.query(query, (err, rows) => {
                if (err) return reject(err);
                resolve(rows);
            });
        });
    }
    ,
    checkPhoneDetailNotification: async function (phone) {
        const query = `SELECT * FROM tb_detailnotification WHERE phone='${phone}'`
        return new Promise((resolve, reject) => {

            connect.connect.query(query, (err, rows) => {
                if (err) return reject(err);
                resolve(rows);
            });
        });
    },
    getListUser: async function (limit, offSet) {
        const query = `SELECT * FROM tb_user LIMIT ${limit} OFFSET ${offSet};
       `;
        return new Promise((resolve, reject) => {
            connect.connect.query(query, (err, rows) => {
                if (err) return reject(err);

                resolve(rows);
            });
        });
    },
    checkAllUser: async function () {
        const query = `SELECT * FROM tb_user
       `;
        return new Promise((resolve, reject) => {
            connect.connect.query(query, (err, rows) => {
                if (err) return reject(err);
                resolve(rows);
            });
        });
    },
    checkWalletBase58: async function (base58) {
        const query = `SELECT * FROM tb_wallets
        WHERE base58 = '${base58}' 
       `;
        return new Promise((resolve, reject) => {

            connect.connect.query(query, (err, rows) => {
                if (err) return reject(err);
                resolve(rows);
            });
        });
    },
    checkProcedureDetailTitle: async function (Procedure) {
        const query = `SELECT * FROM tb_titledetail WHERE IdProcedure = ${Procedure}
        
        `;
        return new Promise((resolve, reject) => {

            connect.connect.query(query, (err, rows) => {
                if (err) return reject(err);
                resolve(rows);
            });
        });
    },
    checkAllDetailTitle: async function () {
        const query = `SELECT * FROM tb_titledetail
        
        `;
        return new Promise((resolve, reject) => {

            connect.connect.query(query, (err, rows) => {
                if (err) return reject(err);
                resolve(rows);
            });
        });
    },
    checkAllProcedure: async function () {
        const query = `SELECT * FROM tb_procedure `
        return new Promise((resolve, reject) => {

            connect.connect.query(query, (err, rows) => {
                if (err) return reject(err);
                resolve(rows);
            });
        });
    },
    checkPhoneWallet: async function (phone) {
        var query = `SELECT * FROM tb_wallets WHERE phone = '${phone}'`
        return new Promise((resolve, reject) => {

            connect.connect.query(query, (err, rows) => {
                if (err) return reject(err);
                resolve(rows);
            });
        });
    },
    checkAllFertilizers: async function (phone) {
        var query = `SELECT * FROM tb_fertilizers`
        return new Promise((resolve, reject) => {

            connect.connect.query(query, (err, rows) => {
                if (err) return reject(err);
                resolve(rows);
            });
        });
    }
}